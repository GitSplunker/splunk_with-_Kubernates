Single node splunk install with AWS APP & TA pre-installed.  

Feb 28, 2017  - updated s3 objects to app version 5.0.2 and TA version 4.2.2 and updated AMI to Splunk Enterprise version 6.5.2

June 28, 2016 - updated s3 objects to app version 4.2.0 and TA version 4.0.0

Feb 3, 2016   - updated s3 objects to app version 4.1.0 and TA version 3.0.0