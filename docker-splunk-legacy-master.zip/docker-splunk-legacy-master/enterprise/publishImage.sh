
docker push splunk/splunk:7.0.3
docker push splunk/splunk:latest
docker push registry.splunk.com/splunk/splunk:7.0.3
docker push registry.splunk.com/splunk/splunk:latest


