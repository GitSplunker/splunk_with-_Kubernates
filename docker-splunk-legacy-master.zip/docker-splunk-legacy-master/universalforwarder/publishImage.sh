#https://docs.docker.com/mac/step_six/
docker push splunk/universalforwarder:7.0.3
docker push splunk/universalforwarder:latest
docker push registry.splunk.com/splunk/universalforwarder:latest
docker push registry.splunk.com/splunk/universalforwarder:7.0.3
