---
name: Enhancement Request
about: Suggest an enhancement to the Splunk Connect for Kubernetes project
title: ''
labels: ''
assignees: ''

---

<<!-- Please only use this template for submitting enhancement requests -->

**What would you like to be added**:

**Why is this needed**:
